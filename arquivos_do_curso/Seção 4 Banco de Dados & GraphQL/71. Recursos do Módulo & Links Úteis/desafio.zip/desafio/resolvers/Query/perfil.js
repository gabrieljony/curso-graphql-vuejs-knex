const db = require('../../config/db')

module.exports = {
    async perfis() {
        // implementar
    },
    async perfil(_, { filtro }) {
        // implementar
    }
}