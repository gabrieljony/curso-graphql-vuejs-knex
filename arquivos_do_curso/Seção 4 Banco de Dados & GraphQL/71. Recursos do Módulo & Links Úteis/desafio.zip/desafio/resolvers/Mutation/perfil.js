const db = require('../../config/db')

module.exports = {
    async novoPerfil(_, { dados }) {
        // implementar
    },
    async excluirPerfil(_, { filtro }) {
        // implementar
    },
    async alterarPerfil(_, { filtro, dados }) {
        // implementar
    }
}