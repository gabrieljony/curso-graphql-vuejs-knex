const db = require('../../config/db')

module.exports = {
    async usuarios() {
        // implementar
    },
    async usuario(_, { filtro }) {
        // implementar
    },
}