const Query = require('./Query')
const Produto = require('./Produto')
const Usuario = require('./Usuario')

module.exports = {
    Query,
    Produto,
    Usuario
}