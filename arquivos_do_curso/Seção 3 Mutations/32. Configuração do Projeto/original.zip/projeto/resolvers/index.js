const Query = require('./Query')
const Usuario = require('./Usuario')

module.exports = {
    Query,
    Usuario
}